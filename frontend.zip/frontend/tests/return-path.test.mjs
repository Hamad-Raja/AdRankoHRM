import {test} from 'node:test';
import assert from 'node:assert/strict';
import {loginDestination} from '../src/lib/return-path.js';

test('login returns to exact own-resource links and report filters',()=>{
 for(const role of ['ADMIN','HR','MANAGER','EMPLOYEE']){
  assert.equal(loginDestination('/my-payslips?payrollId=fixture',role),'/my-payslips?payrollId=fixture');
  assert.equal(loginDestination('/reports?month=2026-11&status=PAID_LEAVE',role),'/reports?month=2026-11&status=PAID_LEAVE');
  assert.equal(loginDestination('/leaves?id=fixture',role),'/leaves?id=fixture');
 }
});
test('login return paths preserve management and employee route permissions',()=>{
 assert.equal(loginDestination('/payroll?status=DRAFT','HR'),'/payroll?status=DRAFT');
 assert.equal(loginDestination('/payroll','EMPLOYEE'),'/dashboard');
 assert.equal(loginDestination('/employees/new','MANAGER'),'/dashboard');
 assert.equal(loginDestination('/my-employees','MANAGER'),'/my-employees');
 assert.equal(loginDestination('/account','UNKNOWN'),'/dashboard');
});
test('external, malformed and unknown return routes cannot redirect away',()=>{
 for(const path of ['https://evil.example','//evil.example','/\\evil.example','/reports\n','/unknown','/api/auth/me',{},null])assert.equal(loginDestination(path,'ADMIN'),'/dashboard');
 assert.equal(loginDestination('/reports?next=https%3A%2F%2Fevil.example','EMPLOYEE'),'/reports?next=https%3A%2F%2Fevil.example');
});
